import POSPage from '../pos'

export default function POSPageExample() {
  return <POSPage />
}
